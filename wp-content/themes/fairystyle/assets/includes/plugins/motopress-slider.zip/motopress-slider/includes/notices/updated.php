<?php
if (!defined('ABSPATH')) exit;
?>
<div id="message" class="updated">
    <h4><?php _e('Thank you for updating to the latest version!', 'motopress-slider'); ?></h4>
</div>